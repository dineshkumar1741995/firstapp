<!-- footer //-->
<tr><td colspan=2>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#442200" height="19">
    <td align="left"><font face="Tahoma, Verdana, Arial" color="#FFFFFF" size="2"><b>&nbsp;&nbsp;Friday, 14th September, 2001</b></font></td>
    <td><font face="Tahoma, Verdana, Arial" color="#FFFFFF" size="2">Operator Name : <? print $user ?></font></td>		
    <td align=right><font face="Tahoma, Verdana, Arial" color="#FFFFFF" size="2"><? language_selector(); ?></font></td>	
  </tr>
</table>
<br>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><font size=-1><a href=https://www.safeweb.com/o/_:http://www.hrs.ricssoft.co.uk/  class=menu>&#169; 2001 RICS</a></td>     	
  </tr>
</table>
</td></tr></table>
<!-- footer_eof //-->
<br>
</body>
</html>