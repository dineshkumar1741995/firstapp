
<table cellpadding=1 cellSpacing=0 width=200 border=0>
  <tr>
    <td>&nbsp;</td>
  </tr>
 <tr>
     <td  noWrap bgcolor=#442200>
	<table border="0" width="100%" cellspacing="0" cellpadding="2">
 	 <tr>
	    <td bgcolor=#ddaa00  nowrap align=center><b><font color=#ffffff><? print TEXT_MAIN ?></b></font></td>
	  </tr>
	</table>
  </td>	
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="reservations.php" class=menu><? print TEXT_CHECK_RESERVATION ?></a> </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="corporates.php" class=menu><? print TEXT_CORPORATE_PARTNERS ?></a></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="rates_special.php" class=menu><? print TEXT_ADD_SPECIAL_OFFER ?></a> </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="inventory.php" class=menu><? print TEXT_ROOM_INVENTORY ?></a></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="occupancy.php" class=menu><? print TEXT_MAX_OCCUPANCY  ?></a></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="query.php" class=menu><? print TEXT_OTCHET ?></a></td>
  </tr>	

  <tr>
   <td  noWrap bgcolor=#442200>
	<table border="0" width="100%" cellspacing="0" cellpadding="2">
 	 <tr>
	    <td bgcolor=#ddaa00  nowrap align=center><b><font color=#ffffff><? print TEXT_SET_RATES ?></b></font></td>
	  </tr>
	</table>
    </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="rates_public.php" class=menu><? print TEXT_PUBLIC ?></a></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="rates_corporate.php" class=menu><? print TEXT_PARTNERS ?></a></td>
  </tr>
  <tr>
	<td  bgcolor=#442200>
	<table border="0" width="100%" cellspacing="0" cellpadding="2">
 	 <tr>
	    <td bgcolor=#ddaa00  align=center><b><font color=#ffffff><? print TEXT_SET_AVAILABILITY ?></b></font></td>
	  </tr>
	</table>
   </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="availability.php?is_corp=0" class=menu><? print TEXT_PUBLIC ?> 
      </a></td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<a href="availability.php?is_corp=1" class=menu><? print TEXT_PARTNERS ?></a></td>
  </tr>
  <tr>
  <td  noWrap bgcolor=#442200>
	<table border="0" width="100%" cellspacing="0" cellpadding="1">
 	 <tr>
	    <td bgcolor=#ddaa00  nowrap align=center><b><font color=#ffffff><? print TEXT_MANAGER_SECTION ?></b></font></td>
	  </tr>
	</table>
 </td>
 </tr>	
  <tr>
    <td>&nbsp;&nbsp;<a href="settings.php" class=menu><? print TEXT_SETTINGS ?></a></td>
  </tr>
 <tr>
    <td>&nbsp;&nbsp;<a href="operators.php" class=menu><? print TEXT_OPERATORS ?></a></td>
  </tr>
 <tr>
    <td>&nbsp;&nbsp;<a href="messages.php" class=menu><? print TEXT_LOGS ?></a></td>
  </tr>
 <tr>
    <td>&nbsp;&nbsp;<a href="statistic.php" class=menu><? print TEXT_STAT ?></a></td>
  </tr>
 <tr>
    <td>&nbsp;&nbsp;<a href="reservations_delete.php" class=menu><? print TEXT_DEL_RESERV ?></a></td>
  </tr>    
  <tr>
    <td>&nbsp;&nbsp;<a href="pages.php" class=menu><? print TEXT_PAGES ?></a></td>
  </tr>    


  <tr>
  	<td  bgcolor=#442200>
	<table border="0" width="100%" cellspacing="0" cellpadding="2">
 	 <tr>
	    <td bgcolor=#ddaa00  align=center><b><font color=#ffffff><? print TEXT_LOGOUT ?></b></font></td>
	  </tr>
	</table>
  </td></tr>	
  <tr>
    <td>&nbsp;&nbsp;<a href="logout.php" class=menu><? print TEXT_LOGOUT ?></a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>

</td></tr></table>

</td> 