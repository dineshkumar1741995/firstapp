<!-- footer //-->
 </TD></TR></TBODY></TABLE>              
  </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR>

   <TR valign=bottom>
   <TD class=a1 noWrap bgColor=#c0c0c0 height=16><B>Operator Name : <? print $user ?> </B></TD>
   <TD class=a1 width=200 bgColor=#c0c0c0 height=16 align=center><a href=mailto:hotel@rics.ru><B>Support</B></A></TD>	  
   <TD valign=bottom align=right><? language_selector(); ?></TD>	
   <TD class=a1 align=right valign=bottom  bgColor=#c0c0c0 ><IMG height=16 src="themes/resizer.jpg" width=16></TD>  
   
</TR></TBODY></TABLE>

<br>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><font size=-1><a href=https://www.safeweb.com/o/_:http://www.hrs.ricssoft.co.uk/  class="glow">&#169; 2001 RICS</a></td>     	
  </tr>
</table>
</td></tr></table>
<!-- footer_eof //-->
<br>
</body>
</html>