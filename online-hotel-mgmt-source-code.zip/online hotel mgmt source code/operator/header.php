<!-- header //-->
<html>
<head>
    <link rel="stylesheet" title="compact" type="text/css" href="main.css">
<title>Rics Hotel Reservation System </title>

<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META content="Hotel Reservation System." name=description>
<META  content="hotels, reservation system" name=keywords>

</head>

<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr bgcolor=#ddaa00>
    <td colspan=2 align="left" valign="middle" nowrap><img src="design/header1.gif" width="57" height="50" border="0" alt=""><img src="images/pixel_trans.gif" width="6" height="1" border="0"><img src="images/header_exchange.gif" width="351" height="50" border="0" alt="Hotel Reservation System"></td>
    
  </tr>
  <tr bgcolor="#442200" height="19">
    <td align="left" nowrap width=220><font size=2>&nbsp;&nbsp;<a href="index.php" class="glow"><b><? print TEXT_ADMINISTRATION_PANEL ?></a></b></font></td>
    <td align="right" nowrap><font size=2><a href="https://www.safeweb.com/o/_:http://www.hrs.ricssoft.co.uk" class=glow><b><? print TEXT_SUPPORT ?></a> &nbsp;|&nbsp; <a href="../index.php" class=glow><? print TEXT_SYSTEM_RESERVATION ?></a> &nbsp;|&nbsp; <a href="index.php" class=glow><? print TEXT_ADMINISTRATION_PANEL ?></a>&nbsp;&nbsp;</b></font></td>
  </tr>


<!-- header_eof //-->