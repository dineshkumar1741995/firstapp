		<tr>
			<td>
				<input type=submit value="Submit">
				</form>
			</td>
		</tr>
	</table>
	</td>
	<td valign=top align=right>
	<? 
		include "../calendar_std.php"; 
		include "../calendar.php"; 
	?>
	</td>
</tr>
</table>

