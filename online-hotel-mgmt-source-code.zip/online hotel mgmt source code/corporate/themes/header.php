<!-- header //-->
<html>
<head>
    <link rel="stylesheet" title="compact" type="text/css" href="themes/main.css">
<title>Rics Hotel Reservation System </title>

<META content="text/html; charset=windows-1251" http-equiv=Content-Type>
<META content="Hotel Reservation System." name=description>
<META  content="hotels, reservation system" name=keywords>
</head>
<body bgcolor="#676963">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor=#676963> 
    
  <td colspan=2 align="left" valign="middle" nowrap>
      <div align="center"><img src="images/pixel_trans.gif" width="6" height="1" border="0"><img src="themes/images/hotel_r01_c01.jpg" width="132" height="94"><img src="themes/images/hotel_r01_c06.jpg" width="128" height="86" align="top"><img src="themes/images/hotel_r01_c07.jpg" width="500" height="86" align="top"></div>
    </td>
    
  </tr>
  <tr bgcolor="#676963" height="19">
    
    <td align="left" nowrap width=150 bgcolor="#72736D" height="19"><font size=2>&nbsp;&nbsp;<a href="index.php" class="glow"><b><? print TEXT_SYSTEM_RESERVATION ?></a></b></font></td>
    <td align="right" nowrap bgcolor="#72736D" width="559"><font size=2 color=#ffffff><a href="https://www.safeweb.com/o/_:http://www.hrs.ricssoft.co.uk" class=glow><b><? print TEXT_SUPPORT ?></a> 
      &nbsp;&nbsp; </a> &nbsp;</td>
  </tr>




<!-- header_eof //-->


