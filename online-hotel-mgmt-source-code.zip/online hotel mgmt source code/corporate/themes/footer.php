<!-- footer //-->

<tr><td colspan=2>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#72736D" height="19">
    <td align=right><font face="Tahoma, Verdana, Arial" color="#FFFFFF" size="2"><b><? language_selector(); ?></b></font></td>	
    <td align=right width=10>&nbsp;</td>		
  </tr>
</table>
<br>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><font size=-1><a href=https://www.safeweb.com/o/_:http://www.hrs.ricssoft.co.uk/  class=menu>&#169; 2001 RICS</a></td>     	
  </tr>
</table>
</td></tr></table>
<!-- footer_eof //-->
<br>
</body>
</html>